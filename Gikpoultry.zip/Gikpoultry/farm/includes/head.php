 <head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>GIKFarms</title>
  
  <link rel="stylesheet" href="assets/vendor/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="assets/vendor/css/vendor.bundle.base.css">
  
  <link rel="icon" type="image/x-icon" href="assets/img/companyimage/favicon.png"
  

  <link rel="stylesheet" href="assets/js/fancybox/jquery.fancybox.css" type="text/css" media="screen">
  <link rel="stylesheet" href="assets/css/style2.css">
  
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  
  
  <link href="assets/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
  <style >
    th { 
      white-space: normal !important;
      word-wrap: break-word;
      hyphens: auto;
    } 

    td { 

      white-space: normal !important;
      word-wrap: break-word;
      hyphens: auto;
      line-height: 20px !important;

    } 
  </style>
  
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
  <script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>

 
</head>